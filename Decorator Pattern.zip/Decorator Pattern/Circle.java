
public class Circle implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("This is Circle's draw()");
        System.out.println("Shape: Circle");
	}

}
