// This is the interface
public interface Employee {
	public void showEmployeeDetails();
}
